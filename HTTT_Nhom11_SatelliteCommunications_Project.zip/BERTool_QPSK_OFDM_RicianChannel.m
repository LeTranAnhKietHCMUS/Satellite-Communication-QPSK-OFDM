%do an
function BER = BERTool_QPSK_OFDM_RicianChannel(EbNo, Rs, numSubcarriers, ...
    cpLength, numSymbolsPerFrame, numPilots, maxNumErrs, maxNumBits)
    rng(12345);
    % Create QPSK Modulator and Demodulator
    QPSKMod = comm.QPSKModulator('BitInput', true, 'PhaseOffset', pi/4);
    QPSKDemod = comm.QPSKDemodulator('BitOutput', true, 'PhaseOffset', pi/4);

    % Rician Channel Parameters
    PathDelays = [0 1e-6];       % Path delays (in seconds) M� t? ?? tr? c?a c�c ???ng truy?n t�n hi?u (t�nh b?ng gi�y).
    PathAvGains = [0 -10];       % Path gains (in dB)
    KFactor = [10 10];           % Increase K-factor to reduce fading
    %H? s? K = 10 => cao, cho th?y t�n hi?u ???ng LOS m?nh h?n nhi?u so v?i t�n hi?u ph?n x?, l�m gi?m fading.
    fD = 5;                      % t?n s? d?ch Doppler t?i ?a (Hz), m� ph?ng m?t k�nh v?i t?c ?? d?ch chuy?n gi?a tr?m ph�t v� tr?m thu th?p.
    DirectPathDopplerShift = [0 0];
    DirectPathInitialPhase = [0 0];

    RicianChannel = comm.RicianChannel( ...
        'SampleRate', Rs, ...
        'PathDelays', PathDelays, ...
        'AveragePathGains', PathAvGains, ...
        'KFactor', KFactor, ...
        'MaximumDopplerShift', fD, ...
        'DirectPathDopplerShift', DirectPathDopplerShift, ...
        'DirectPathInitialPhase', DirectPathInitialPhase, ...
        'NormalizePathGains', true ...
    );

    % AWGN Channel Parameters
    k = 2; % Bits per QPSK symbol
    SNR = EbNo + 10*log10(k);   % Calculate SNR based on Eb/No
    AWGNChannel = comm.AWGNChannel('NoiseMethod', 'Signal to noise ratio (SNR)', ...
        'SNR', SNR);

    % BER Calculator
    BERCalc = comm.ErrorRate;

    % Pilot Allocation
    pilotSpacing = floor(numSubcarriers / numPilots);
    pilotIndices = 1:pilotSpacing:numSubcarriers;

    if length(pilotIndices) ~= numPilots
        error('Number of pilots (numPilots) does not match length of pilotIndices.');
    end

    % Adjust numSymbolsPerFrame to include complete frames
    numOFDMFrames = ceil(numSymbolsPerFrame / (numSubcarriers - numPilots));
    adjustedNumSymbols = numOFDMFrames * (numSubcarriers - numPilots);

    BERIm = zeros(3, 1); % Initialize BER storage

    % Perform Simulation
    while BERIm(2) < maxNumErrs && BERIm(3) < maxNumBits
        % Generate Random Bits
        txBits = randi([0 1], adjustedNumSymbols * k, 1); 
        %T?o d? li?u bit ng?u nhi�n ?? truy?n.

        % QPSK Modulation
        txSymbols = QPSKMod(txBits); 
        %?i?u ch? bit th�nh k� hi?u QPSK

        % Reshape to match OFDM structure
        txOFDM = reshape(txSymbols, numSubcarriers - numPilots, numOFDMFrames);
        %??a d? li?u v�o khung OFDM.

        % Insert Pilots
        txOFDMWithPilots = zeros(numSubcarriers, numOFDMFrames);
        dataIndices = setdiff(1:numSubcarriers, pilotIndices);
        txOFDMWithPilots(dataIndices, :) = txOFDM;
        txOFDMWithPilots(pilotIndices, :) = 1;

        % Add Cyclic Prefix
        txOFDM_cp = [txOFDMWithPilots(end-cpLength+1:end, :); txOFDMWithPilots];
        txOFDMFlattened = txOFDM_cp(:);

        % Pass through Rician Channel
        rxOFDMChan = RicianChannel(txOFDMFlattened);
        %Truy?n t�n hi?u qua k�nh Rician.

        % Add AWGN
        AWGNChannel.SignalPower = var(txOFDMFlattened);
        rxOFDM = AWGNChannel(rxOFDMChan);
        %Th�m nhi?u AWGN:

        % Remove Cyclic Prefix
        rxOFDMReshaped = reshape(rxOFDM, numSubcarriers + cpLength, []);
        rxOFDM_noCP = rxOFDMReshaped(cpLength+1:end, :);

        % Channel Estimation with Linear Interpolation
        hEst = mean(rxOFDM_noCP(pilotIndices, :) ./ txOFDMWithPilots(pilotIndices, :), 2);
        hEstFull = interp1(pilotIndices, hEst, 1:numSubcarriers, 'linear', 'extrap');
        rxOFDMEqualized = rxOFDM_noCP ./ hEstFull.';
        %??c l??ng k�nh v� c�n b?ng t�n hi?u

        % Extract Data Symbols
        rxDataSymbols = rxOFDMEqualized(dataIndices, :);
        rxDataSymbolsFlattened = rxDataSymbols(:);

        % QPSK Demodulation
        rxBits = QPSKDemod(rxDataSymbolsFlattened);
        %Gi?i ?i?u bi?n QPSK

        % BER Calculation
        BERIm = BERCalc(txBits, rxBits);
        %T�nh bit l?i
    end

    % Output BER
    BER = BERIm(1);
    disp(['BER = ', num2str(BER), ' after ', num2str(BERIm(3)), ' bits.']);
end
